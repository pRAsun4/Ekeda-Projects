const ranImg = document.getElementById("opponentImg");
const imgId = document.getElementById("displayImg");
const winner = document.getElementById("win");
const myPoint = document.getElementById("Your_point");
const opponentPoint = document.getElementById("opponent_point");
var options = ["Rock", "Paper", "Scissor"];
var human;

function rock () {
    human = "Rock";
    imgId.src = "rock.png";
   
    var computer = opponentPlayer();
    if (computer === "Rock") {
        ranImg.src = "rock.png";
    }
    else if(computer === "Paper") {
        ranImg.src = "paper.png";
    }
    else if (computer === "Scissor") {
        ranImg.src = "scissor.png";
    }

    game();
}


function paper () {
    human = "Paper";
    imgId.src = "paper.png";
    var computer = opponentPlayer();
    if (computer === "Rock") {
        ranImg.src = "rock.png";
    }
    else if(computer === "Paper") {
        ranImg.src = "paper.png";
    }
    else if (computer === "Scissor") {
        ranImg.src = "scissor.png";
    }

    game();
}

function scissor () {
    human = "Scissor";
    imgId.src = "scissor.png";
    var computer = opponentPlayer();
    if (computer === "Rock") {
        ranImg.src = "rock.png";
    }
    else if(computer === "Paper") {
        ranImg.src = "paper.png";
    }
    else if (computer === "Scissor") {
        ranImg.src = "scissor.png";
    }

    game();
}

function opponentPlayer () {
    
    var randomImg = Math.floor(Math.random() * options.length);
    return options[randomImg];
}

function playround (human, computer) {
    if(human == computer){
        return "Its a Draw !!";
    }
    else if (human =='Rock' && computer == 'Paper') {
        return "You Lose";
    }
    else if (human =='Paper' && computer == 'Scissor'){
        return "You Lose";
    }
    else if (human =='Scissor' && computer == 'Rock') {
        return "you Lose";
    }
    else {
        return "You Win..";
    }
}

function game () {
   
    var computer = opponentPlayer();
    var result = playround(human, computer);
    console.log(result);
}
